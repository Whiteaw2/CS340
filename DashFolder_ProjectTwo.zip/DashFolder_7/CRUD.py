#Example Python Code to Insert a Document
from pprint import pprint
from pymongo import MongoClient
from pymongo import errors
from bson.objectid import ObjectId
from pymodm.connection import connect
import sys

class AnimalShelter:
	""" CRUD operations for Animal collection in MongoDB """

	def __init__(self, username, password):	 
		
		# Connection Variables
		USER = username #'aacuser'
		PASS = password #'securePassword'
		HOST = 'nv-desktop-services.apporto.com'
		PORT = 32489
		DB = 'AAC'
		COL = 'animals'
		
		#mongosh
		#
		# Initialize Connection
		#
		self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
		self.database = self.client['%s' % (DB)]
		self.collection = self.database['%s' % (COL)]

		#debug for server connection below
		#db = self.client
		#print(db.server_info())
		
		#print("initialization result: ") + str(result))
   

        #CREATE
	def create(self, data):#, exactMatch): #removed call to .read
		try: 
			if data is not None and data:
				self.database.animals.insert_one(data)
				print("True")

			    	# verify by printing document list
				#print("Reading all relevant entries.")
				#self.read(data, exactMatch)
			else:
				print("False")
				#print("Nothing to save, because data parameter is empty")
		except errors.PyMongoError as e:

			print("False")
			

	#READ 
	def read(self, data, exactMatch, findOne):
		query = {}
		result = None
		if data:
			for key, value in data.items():
				if isinstance(value, str):  # Check if value is string
					if exactMatch:
						query[key] = value  #Exact match
					else:
						query[key] = {"$regex": value, "$options": "i"}  # Use regex case-insense matching
				else:
					query[key]= value 
				if findOne:
					result = self.database.animals.find_one(query)
					if result is not None:
						result = [result]
			else:
				result = list(self.database.animals.find(query))
		else:
			result = list(self.database.animals.find({}))
		return result

	#UPDATE 
	def update(self, data, update_data, scopeNumber):#, exactMatch): #removed call to .read
		#initialize list for return confirmation
		result = list()
		
		#scopeNumber = "one"
		
		try: 
			items = iter(data.items())
			key, value = next(items)
			query = { key : {"$regex":f"^{value}$", "$options": 'i'}}
			#todo: to add flexible iterator to assign dynamic assignment to many dictionary entries if needed.
			
			#debug for check input types below
			#print(key + " : " + str(type(key)) + " " + value + " : " + str(type(key)) )
			
			#submit query
			if scopeNumber == "one":
				result = self.database.animals.update_one(query, {'$set': update_data})
			#elif scopeNumber == "all":
			#	result = self.database.animals.update_many(query)
			
			#print out number of deleted items
			print(f"{result.modified_count} documents updated.")
			
			#verify by printing document list
			#self.read(data, exactMatch)
			
		except errors.PyMongoError as e:
				print("Nothing to delete, because data parameter is empty")
				return False
			
			
        #DELETE
        #WARNING: This deletes all of a particular field and value currently (all entries of that type)
	def delete(self, data):#, exactMatch): #removed call to .read
		try: 
			items = iter(data.items())
			key, value = next(items)
			query = { key : {"$regex":f"^{value}$", "$options": 'i'}}
			#todo: to add flexible iterator to assign dynamic assignment to many dictionary entries if needed.
			
			#debug for check input types below
			#print(key + " : " + str(type(key)) + " " + value + " : " + str(type(key)) )
			
			#submit query
			result = self.database.animals.delete_many(query)
			
			#print out number of deleted items
			print(f"{result.deleted_count} documents deleted.")
			
			#verify by printing document list
			#self.read(data, exactMatch)
			
		except errors.PyMongoError as e:
				print("Nothing to delete, because data parameter is empty")
				return False
        			
